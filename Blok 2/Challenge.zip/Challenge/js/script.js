function picture(){ 
    document.getElementById('pic').style.display='block';
}
function code() {
    document.getElementById('code').style.display='block';
}
function setColor(element, kleur){ 

    element.style.color = kleur; 

}
function hideMe(){
document.getElementById("blok").style.display = "none"; 
document.getElementById("show").style.display = "block"; 
}
function show(){
    document.getElementById("blok").style.display = "block";
    document.getElementById("show").style.display = "none";
}

function pa() {
    document.getElementById('blok').style.display='block';
}